-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 21, 2021 at 07:48 AM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `jdbc`
--
CREATE DATABASE IF NOT EXISTS `jdbc` DEFAULT CHARACTER SET utf8 COLLATE utf8_bin;
USE `jdbc`;
-- --------------------------------------------------------

--
-- Table structure for table `ad`
--

CREATE TABLE `ad` (
  `us` varchar(100) NOT NULL,
  `ps` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `ad`
--

INSERT INTO `ad` (`us`, `ps`) VALUES
('admin', '123');

-- --------------------------------------------------------

--
-- Table structure for table `asp`
--

CREATE TABLE `asp` (
  `id` int(11) NOT NULL DEFAULT 0 COMMENT 'TRIAL',
  `qs` longtext DEFAULT NULL COMMENT 'TRIAL',
  `op1` longtext DEFAULT NULL COMMENT 'TRIAL',
  `op2` longtext DEFAULT NULL COMMENT 'TRIAL',
  `op3` longtext DEFAULT NULL COMMENT 'TRIAL',
  `op4` longtext DEFAULT NULL COMMENT 'TRIAL',
  `ans` longtext DEFAULT NULL COMMENT 'TRIAL',
  `trial380` char(1) DEFAULT NULL COMMENT 'TRIAL'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='TRIAL';

--
-- Dumping data for table `asp`
--

INSERT INTO `asp` (`id`, `qs`, `op1`, `op2`, `op3`, `op4`, `ans`, `trial380`) VALUES
(1, 'HTML stands for:', 'Huge Makeup Language', 'Huge Text Makeup Language', 'Hypertext Makeup Language', 'Hypertext Markup Language', 'Hypertext Markup Language', 'T'),
(2, 'Which symbol is used to enclose HTML tags?', '()', '<>', '[]', '{}', '<>', 'T'),
(3, 'Which symbol identifies an HTML end tag?', '!', '|', '/', '\\', '/', 'T'),
(4, 'Which HTML tag does not use an end tag?', 'B', 'center', 'HR', 'U', 'HR', 'T'),
(5, 'Where does a web application reside?', 'Web client', 'Web server', 'Both a and b', 'All of the above', 'Web server', 'T'),
(6, 'Which is an example of a web document?', 'Server script', 'Web page', 'Client browser', 'Both a and b', 'Both a and b', 'T'),
(7, 'A postback occurs when:', 'a browser posts a form to the server', 'a user’s action activates the handing of a server event', 'a server posts a form to the client', 'Both a and b', 'Both a and b', 'T'),
(8, 'Which set of symbols are used to signify the presence of ASP.NET code?', '<@', '<#', '<$', '<%', '<%', 'T'),
(9, 'Which is the file extension used for an ASP.NET file?', 'asn', 'asp', 'aspx', 'aspn', 'aspx', 'T'),
(10, 'What is the extension for a Visual Basic web form interface file', 'asp', 'aspx', 'asp.vb', 'aspx.vb', 'aspx', 'T'),
(11, 'Which user action will not generate a server-side event?', 'Mouse Move', 'Text Change', 'Button Click', 'Both a and b', 'Mouse Move', 'T'),
(12, 'Which property is used to name a web control', 'ControlName', 'Designation', 'ID', 'Name', 'ID', 'T'),
(13, 'Which language is used to create an ASP.NET code file', 'Visual Basic', 'C#', 'C++', 'All of the above', 'All of the above', 'T'),
(14, 'A method in a class is', 'a sub procedure', 'a function', 'an event', 'Both a and b', 'Both a and b', 'T'),
(15, 'Methods are used to represent', 'actions', 'classes', 'data', 'events', 'actions', 'T'),
(16, 'Anything in VB.NET that has a property or method is', 'a class', 'a control', 'an object', 'All of the above', 'an object', 'T'),
(17, 'A constructor is a special type of', 'class', 'field', 'method', 'property', 'method', 'T'),
(18, 'Properties are used to represent', 'actions', 'classes', 'data', 'events', 'data', 'T'),
(19, 'Which of the following is part of an object', 'Methods', 'Properties', 'Instances', 'Both a and b', 'Both a and b', 'T'),
(20, 'Where does the query string store information', 'HTML source', 'Text file', 'URL', 'Both a and b', 'URL', 'T'),
(21, 'Where do cookies store information', 'HTML source', 'Text file', 'URL', 'Both a and b', 'Text file', 'T'),
(22, 'What symbol specifies the beginning of a query string', '@', '#', '$', '?', '?', 'T'),
(23, 'Which control is an example of an object in VB.NET', 'Button', 'Label', 'Textbox', 'All of these', 'All of these', 'T'),
(24, 'Polymorphism can apply to', 'math operators', 'method names', 'object names', 'Both a and b', 'Both a and b', 'T'),
(25, 'Which client-side technique can be disabled by the end-user', 'Cookies', 'Query string', 'View state', 'All of the above', 'Cookies', 'T'),
(26, 'What is the syntax for creating and using an application variable?', 'Application.VariableName = Value', 'Application.VariableName = (Value)', 'Application(VariableName) = Value', 'Application(“VariableName”) = Value', 'Application(“VariableName”) = Value', 'T'),
(27, 'Which server-side technique is available in ASP.NET?', 'Application states', 'Session states', 'Database support', 'Both a and b.', 'Both a and b.', 'T'),
(28, 'An Application variable is created', 'The application is first placed on a web server', 'The web server is first started.', 'The first client requests a URL resource', 'every time a client requests a URL resource', 'The first client requests a URL resource', 'T'),
(29, 'A Session variable is created', 'The application is first placed on a web server', 'The web server is first started', 'The first client requests a URL resource.', 'every time a new client interacts with the web application', 'every time a new client interacts with the web application', 'T'),
(30, 'If there is no activity from a browser, how long will a session variable last?', '10 minutes', '20 minutes', '60 minutes', '100 minutes', '20 minutes', 'T'),
(31, 'Which is not a reason for using a database to store state information?', 'The capacity to store high volumes of information', 'The ability to use data mining techniques on the stored information', 'The ability to use application and session variables', 'Security from unauthorized use', 'The ability to use application and session variables', 'T'),
(32, 'Which control is an example of an object in VB.NET?', 'Button', 'Label', 'TextBox', 'All of the above.', 'All of the above.', 'T'),
(33, 'Which of the following is part of an object?', 'Methods', 'Properties', 'Instances', 'Both a and b', 'Both a and b', 'T'),
(34, 'Which is true about objects?', 'Objects are used to create classes', 'Objects are analogous to blueprints', 'Objects combine actions and data.', 'Both a and b.', 'Objects combine actions and data.', 'T'),
(35, 'Properties are used to represent', 'actions.', 'classes.', 'data.', 'events.', 'data', 'T'),
(36, 'Methods are used to represent:', 'actions.', 'classes.', 'data.', 'events.', 'actions.', 'T'),
(37, 'The term instantiation refers to the creation of:', 'a class from a blueprint.', 'an object from a class', 'a method from an object.', 'a property from a method.', 'an object from a class.', 'T'),
(38, 'Anything in VB.NET that has a property or method is:', 'a class', 'a control', 'an object', 'Both a and b.', 'an object', 'T'),
(39, 'Which feature is needed to make a programming language object oriented?', 'Encapsulation', ' Inheritance', 'Polymorphism', 'All of the above.', 'All of the above.', 'T'),
(40, 'Encapsulation makes it easier to:', 'reuse and modify existing modules of code', 'write and read code by sharing method names.', 'hide and protect data from external code.', 'Both a and b.', 'hide and protect data from external code', 'T'),
(41, 'Inheritance makes it easier to:', 'reuse and modify existing modules of code.', 'write and read code by sharing method names', 'hide and protect data from external code.', 'Both a and b.', 'reuse and modify existing modules of code.', 'T'),
(42, 'Polymorphism makes it easier to:', 'reuse and modify existing modules of code.', 'write and read code by sharing method names.', 'hide and protect data from external code.', 'Both a and b', 'write and read code by sharing method names.', 'T'),
(43, 'The standard prefix to signify a class is:', 'B', 'C', 'L', 'T', 'T', 'T'),
(44, 'When using encapsulation how should data be shared with external code?', 'Events', 'Methods', 'Properties', 'Private variables', 'Properties', 'T'),
(45, 'When a base class is changed:', 'there is no effect on the derived class', 'only the methods of the derived class change.', 'only the properties of the derived class change.', 'the derived class automatically changes.', 'the derived class automatically changes.', 'T'),
(46, 'Polymorphism can apply to', 'math operators.', 'method names.', 'object names.', 'Both a and b.', 'Both a and b.', 'T'),
(47, 'With polymorphism:', 'one method can have multiple names.', 'one object can have multiple names', 'many methods can share the same name.', 'many objects can share the same name.', 'many methods can share the same name.', 'T'),
(48, 'Which element of a class is optional?', 'Constructs', 'Fields', 'Methods', 'All of the above', 'All of the above', 'T'),
(49, 'What is the suggested order for the definition of class elements from first to last?', 'Constructs, fields, methods, properties', 'Properties, constructs, fields, methods', 'Fields, properties, constructs, methods', 'Constructs, properties, fields, methods', 'Fields, properties, constructs, methods', 'T'),
(50, 'The standard for designing a field is that it be defined as a', 'private method', 'public method', 'private variable', 'public variable.', 'private variable', 'T');

-- --------------------------------------------------------

--
-- Table structure for table `cplus`
--

CREATE TABLE `cplus` (
  `id` int(11) NOT NULL DEFAULT 0 COMMENT 'TRIAL',
  `qs` longtext DEFAULT NULL COMMENT 'TRIAL',
  `op1` longtext DEFAULT NULL COMMENT 'TRIAL',
  `op2` longtext DEFAULT NULL COMMENT 'TRIAL',
  `op3` longtext DEFAULT NULL COMMENT 'TRIAL',
  `op4` longtext DEFAULT NULL COMMENT 'TRIAL',
  `ans` longtext DEFAULT NULL COMMENT 'TRIAL',
  `trial141` char(1) DEFAULT NULL COMMENT 'TRIAL'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='TRIAL';

--
-- Dumping data for table `cplus`
--

INSERT INTO `cplus` (`id`, `qs`, `op1`, `op2`, `op3`, `op4`, `ans`, `trial141`) VALUES
(1, 'The address of a variable temp of type float is', '*temp', '&temp', 'float& temp', 'float temp&', '&temp', 'T'),
(2, 'The process of building new classes from existing one is called ______.', 'Polymorphism', 'Structure', 'Inheritance', 'None', 'Inheritance', 'T'),
(3, 'If the variable count exceeds 100, a single statement that prints \"Too many\" is', 'if (count<100) cout << \"Too many\";', 'if (count>100) cout >> \"Too many\";', 'if (count>100) cout << \"Too many\";', 'None of these.', 'if (count>100) cout << \"Too many\";', 'T'),
(4, 'Usually a pure virtual function', 'has complete function body.', 'will never be called.', 'will be called only to delete an object.', 'is defined only in derived class.', 'is defined only in derived class.', 'T'),
(5, 'To perform stream I/O with disk files in C++, you should', 'open and close files as in procedural languages.', 'use classes derived from ios.', 'use C language library functions to read and write data.', 'include the IOSTREAM.H header file.', 'use classes derived from ios.', 'T'),
(6, 'Overloading the function operator', 'requires a class with an overloaded operator.', 'requires a class with an overloaded [ ] operator.', 'allows to create objs,act syntactically like funcs', 'usually make use of a constructor that takes arguments.', 'requires a class with an overloaded operator.', 'T'),
(7, 'Array declare as int a[4]={3,0,1,2},then values assign to a[0] & a[4] will be ____', '3, 2', '0, 2', '3, 0', '0, 4', '3, 0', 'T'),
(8, 'Mechanism of deriving a class from another derived class is known as____', 'Polymorphism', 'Single Inheritance', 'Multilevel Inheritance', 'Message Passing', 'Multilevel Inheritance', 'T'),
(9, 'RunTime Polymorphism is achieved by ______', 'friend function', 'virtual function', 'operator overloading', 'function overloading', 'virtual function', 'T'),
(10, 'Fn call method,pass args to fn by pass a copy of args\'s values is_______', 'call by name', 'call by value', 'call by reference', 'call by value result', 'call by value', 'T'),
(11, 'In C++, dynamic memory allocation is accomplished with the operator ____', 'new', 'this', 'malloc()', 'delete', 'new', 'T'),
(12, 'If we create a file by ‘ifstream’, then the default mode of the file is _________', 'ios :: out', 'ios :: in', 'ios :: app', 'ios :: binary', 'ios :: in', 'T'),
(13, 'A variable defined within a block is visible', 'from the point of definition onward in the program.', 'from the point of definition onward in the function.', 'from the point of definition onward in the block.', 'throughout the function.', 'from the point of definition onward in the block.', 'T'),
(14, 'The break statement causes an exit', 'The break statement causes an exit', 'only from the innermost switch.', 'from all loops & switches.', 'from the innermost loop or switch.', 'from the innermost loop or switch.', 'T'),
(15, 'Which of the following cannot be legitimately passed to a function', 'A constant.', 'A variable.', 'A structure.', 'A header file.', 'A header file.', 'T'),
(16, 'A property which is not true for classes is that they', 'are removed from memory when not in use.', 'permit data to be hidden from same classes.', 'permit data to be hidden from other classes.', 'Can closely model objects in the real world.', 'permit data to be hidden from other classes.', 'T'),
(17, 'You can read input that consists of multiple lines of text using', 'the normal cout << combination.', 'the cin.get( ) function with one argument.', 'the cin.get( ) function with two arguments.', 'the cin.get( ) function with three arguments.', 'the cin.get( ) function with two arguments.', 'T'),
(18, 'The keyword friend does not appear in', 'the class allowing access to another class.', 'the class desiring access to another class.', 'the private section of a class.', 'the public section of a class.', 'the private section of a class.', 'T'),
(19, 'The process of building new classes from existing one is called', 'Structure.', 'Inheritance.', 'Polymorphism.', 'Template.', 'Inheritance.', 'T'),
(20, 'If you wanted to sort many large objects or structures, it would be most efficient to', 'place them in an array & sort the array.', 'place pointers to them in an array & sort the array.', 'place them in a linked list and sort the linked list.', 'place references to them in an array and sort the array.', 'place them in a linked list and sort the linked list.', 'T'),
(21, 'Which statement gets affected when i++ is changed to ++i?', 'i = 20; i++;', 'for (i = 0; i<20; i++) { }', 'a = i++;', 'while (i++ = 20) cout <<i;', 'i = 20; i++;', 'T'),
(22, 'A friend function to a class, C cannot access', 'private data members and member functions.', 'public data members and member functions.', 'protected data members and member functions.', 'the data members of the derived class of C.', 'the data members of the derived class of C.', 'T'),
(23, 'The operator that cannot be overloaded is', '++', '::', '( )', '~', '::', 'T'),
(24, 'A struct is the same as a class except that', 'there are no member functions.', 'all members are public.', 'cannot be used in inheritance hierarchy.', 'it does have a this pointer.', 'cannot be used in inheritance hierarchy.', 'T'),
(25, 'Pure virtual functions', 'have to be redefined in the inherited class.', 'cannot have public access specification.', 'are mandatory for a virtual class.', 'None of the above.', 'have to be redefined in the inherited class.', 'T'),
(26, 'Additional information sent when an exception is thrown may be placed in', 'the throw keyword.', 'the throws keyword.', 'the catch block.', 'an object of the exception class.', 'the catch block.', 'T'),
(27, 'Use of virtual functions implies', 'overloading.', 'overriding.', 'static binding.', 'dynamic binding.', 'dynamic binding.', 'T'),
(28, 'this pointer', 'implicitly points to an object.', 'can be explicitly used in a class.', 'can be used to return an object.', 'All of the above.', 'All of the above.', 'T'),
(29, 'Within a switch statement', 'Continue can be used but Break cannot be used', 'Continue cannot be used but Break can be used', 'Both Continue and Break can be used', 'Neither Continue nor Break can be used', 'Continue cannot be used but Break can be used', 'T'),
(30, 'Data members which are static', 'cannot be assigned a value', 'can only be used in static functions', 'cannot be defined in a Union', 'can be accessed outside the class', 'can only be used in static functions', 'T'),
(31, 'Which of the following is false for cin?', 'It represents standard input.', 'It is an object of istream class.', 'It is a class of which stream is an object.', 'Using cin the data can be read from user’s terminal.', 'It is a class of which stream is an object.', 'T'),
(32, 'It is possible to declare as a friend', 'a member function', 'a global function', 'a class', 'all of the above', 'all of the above', 'T'),
(33, 'In multiple inheritance', 'the base classes must have only default constructors', 'cannot have virtual functions', 'can include virtual classes', 'None of the above.', 'can include virtual classes', 'T'),
(34, 'Declaration of a pointer reserves memory space', 'for the object.', 'for the pointer.', 'both for the object and the pointer.', 'none of these.', 'for the pointer.', 'T'),
(35, 'for (; ;)', 'means the test is done by some expression is always true', 'is not valid', 'will loop forever', 'should be written as for( )', 'will loop forever', 'T'),
(36, 'The operator << when overloaded in a class', 'must be a member function', 'must be a non member function', 'can be both (a) & (b) above', 'cannot be overloaded', 'can be both (a) & (b) above', 'T'),
(37, 'A virtual class is the same as', 'an abstract class', 'a class with a virtual function', 'a base class', 'none of the above.', 'none of the above.', 'T'),
(38, 'Identify the operator that is NOT used with pointers', '->', '&', '*', '>>', '>>', 'T'),
(39, 'In which case is it mandatory to provide a destructor in a class?', 'Almost in every class', 'Class for which two or more than two objects will be created', 'Class for which copy constructor is defined', 'Class whose objects will be created dynamically', 'Class whose objects will be created dynamically', 'T'),
(40, 'The members of a class, by default, are', 'public', 'protected', 'private', 'mandatory to specify', 'private', 'T'),
(41, 'Exception handling is targeted at', 'Run-time error', 'Compile time error', 'Logical error', 'All of the above.', 'Run-time error', 'T'),
(42, 'A pointer to the base class can hold address of', 'only base class object', 'only derived class object', 'base class object as well as derived class object', 'None of the above', 'base class object as well as derived class object', 'T'),
(43, 'Function templates can accept', 'any type of parameters', 'only one parameter', 'only parameters of the basic type', 'only parameters of the derived type', 'only parameters of the basic type', 'T'),
(44, 'How many constructors can a class have?', '0', '1', '2', 'any number', 'any number', 'T'),
(45, 'The new operator', 'returns a pointer to the variable', 'creates a variable called new', 'obtains memory for a new variable', 'tells how much memory is available', 'obtains memory for a new variable', 'T'),
(46, 'An exception is caused by', 'a hardware problem', 'a problem in the operating system', 'a syntax error', 'a run-time error', 'a run-time error', 'T'),
(47, 'A template class', 'is designed to be stored in different containers', 'works with different data types', 'generates objects which must be identical', 'generates classes with different numbers of member functions.', 'works with different data types', 'T'),
(48, 'A library function exit() causes an exit from', 'the loop in which it occurs', 'the block in which it occurs', 'the function in which it occurs', 'the program in which it occurs', 'the program in which it occurs', 'T'),
(49, 'RunTime polymorphism is achieved by ________', 'friend function', 'virtual function', 'operator overloading', 'function overloading', 'virtual function', 'T'),
(50, 'Declaration of a pointer reserves memory space', 'for the object.', 'for the pointer.', 'both for the object and the pointer.\r\nboth for the object and the pointer.', 'none of these.', 'for the pointer.', 'T');

-- --------------------------------------------------------

--
-- Table structure for table `java`
--

CREATE TABLE `java` (
  `id` int(11) NOT NULL DEFAULT 0 COMMENT 'TRIAL',
  `qs` longtext DEFAULT NULL COMMENT 'TRIAL',
  `op1` longtext DEFAULT NULL COMMENT 'TRIAL',
  `op2` longtext DEFAULT NULL COMMENT 'TRIAL',
  `op3` longtext DEFAULT NULL COMMENT 'TRIAL',
  `op4` longtext DEFAULT NULL COMMENT 'TRIAL',
  `ans` longtext DEFAULT NULL COMMENT 'TRIAL',
  `trial581` char(1) DEFAULT NULL COMMENT 'TRIAL'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='TRIAL';

--
-- Dumping data for table `java`
--

INSERT INTO `java` (`id`, `qs`, `op1`, `op2`, `op3`, `op4`, `ans`, `trial581`) VALUES
(1, 'Select all correct declarations, or declaration and initializations of an array?', ' String str[];', ' String str[]=new String [] {\"string1\", \"string 2\", \"string3\", \"string4\",\"string5\"};', 'String str[]= {\"string1\",\"string2\", \"string3\", \"string4\", \"string5\"};', 'All of the above', 'All of the above', 'T'),
(2, 'What is a String?', 'A combination of characters', 'A combination of characters is called as string', 'both', 'None of these', 'A combination of characters is called as string', 'T'),
(3, 'The synchronized is used in which of the following?', 'Class declarations.', ' Method declarations', 'Block of code declarations', 'Variable declarations.', ' Method declarations', 'T'),
(4, 'Which of the statements are true?', 'Overridden methods have the same method name and signature', 'Overloaded methods have the same method name and signature', 'Overridden methods have the same method name and different signature', 'Overloaded methods have the same method name and different signature', 'Overridden methods have the same method name and signature', 'T'),
(5, 'Which statements about garbage collection are true?', 'The garbage collector runs in low memory situations', 'You can run the garbage collector when ever you want.', 'When it runs, it releases the memory allocated by an object.', 'Garbage collector immediately runs when you set the references to null.', 'The garbage collector runs in low memory situations', 'T'),
(6, 'String are instances of the class String', 'True', 'False', 'none', 'none of these', 'True', 'T'),
(7, 'Select all correct list of keywords?', 'superclass', 'goto', 'open', 'import, package', 'goto', 'T'),
(8, 'Select the correct form for anonymous inner class declaration ?', 'new Outer.new Inner', 'new Inner() {', 'new Inner()', 'Outer.new Inner()', 'new Inner() {', 'T'),
(9, 'Which of the following statements are true?', 'An anonymous class cannot have any constructors', 'An anonymous class can only be created within the body of a method', 'An anonymous class can only access static fields of the enclosing class', 'An anonymous class instantiated and declared in the same place.', 'An anonymous class cannot have any constructors', 'T'),
(10, 'Which of the following class definitions are legal declaration of an abstract class?', 'class A { abstract void Method() {} }', 'abstract class A { abstract void Method() ; }', 'class A { abstract void Method() {System.out.println(\"Test\");} }', 'class abstract A { abstract void Method() {} }', 'abstract class A { abstract void Method() ; }', 'T'),
(11, 'Which of the following declare an array of string object?', 'String[] s;', 'String []s;', 'String s[];', 'all of these', 'all of these', 'T'),
(12, 'Which of the following assignment statements is invalid?', 'long l = 698.65;', 'float f = 55.8;', 'double d = 0x45876;', 'All of the above', 'long l = 698.65;', 'T'),
(13, 'What is the numeric range for a Java int data type?', ' 0 to (2^32)', '-(2^31) to (2^31)', '-(2^31) to (2^31 - 1)', '-(2^15) to (2^15 - 1)', '-(2^31) to (2^31 - 1)', 'T'),
(14, 'Which of the following method returns the ID of an event?', 'int getID()', 'String getSource()', 'int returnID()', ' int eventID()', 'int getID()', 'T'),
(15, 'What is correct about event handling in Java?', 'Java1.0 event handl. compatible with event delegation model', 'Java 1.0 and Java 1.1 event handling models are not compatible', 'Event listeners are the objects that implements listener interfaces', 'You can add multiple listeners to any event source', 'You can add multiple listeners to any event source', 'T'),
(16, 'The byte with a value of 01110111,which following produce 00111011?', '0x77 << 1;', '0x77 >>> 1;', '0x77 >> 1;', 'None of the above', '0x77 >>> 1;', 'T'),
(17, 'Which of the following are primitive types?', 'byte', 'String', 'integer', 'Float', 'byte', 'T'),
(18, 'Java support multidimentional arrays.', 'True', 'False', 'none', 'none of these', 'True', 'T'),
(19, 'How can you implement encapsulation.', 'By making methods private and variable private', 'By making methods are public and variables as private', 'Make all variable are public and access them using methods', 'Making all methods and variables as protected.', 'By making methods are public and variables as private', 'T'),
(20, 'public void amethod(int i, String s){}', 'public void amethod(String s, int i){}', 'public int amethod(int i, String s){}', 'public void amethod(int i, String mystring){}', 'public void Amethod(int i, String s) {}', 'public void amethod(String s, int i){}', 'T'),
(21, 'Which of the following statements are true?', 'An anonymous inner class cannot have any constructors', 'An anonymous inner class can created only inside a method.', 'An anonymous inner class can only access static fields of the enclosing', 'An anonymous inner class can implement an interface', 'An anonymous inner class cannot have any constructors', 'T'),
(22, 'Which statements are true?', 'Threads start() method automatically calls run()', 'Thread dies after the run() returns', 'A dead Thread can be started again.', 'A stop() method kills the currently running Thread', 'A stop() method kills the currently running Thread', 'T'),
(23, 'The ThreadGroup class instance?', 'Allow threads to be manipulated as group', 'Provide support for ThreadDeath listeners', 'May contain other ThreadGroups', 'Must contain threads of the same type', 'Allow threads to be manipulated as group', 'T'),
(24, 'Default Layout Managers are concerned ?', 'Frame\'s default Layout Manager is Border', 'Applet\'s is FlowLayout', 'Panel\'s is FlowLayout', 'All of the above', 'All of the above', 'T'),
(25, 'Which statements are true about GridBagLayout ?', 'Weight x and weight y should be 0.0 and 1.0', 'If fill is both, anchor does not make sense.', 'It divides its territory in to an array of cells.', 'All of the above', 'All of the above', 'T'),
(26, 'Which of the following are true?', 'gridwidth, gridheight, specifies how many columns and rows to span.', 'gridx, gridy has GridBagConstraints.', 'both', 'none of these', 'gridwidth, gridheight, specifies how many columns and rows to span.', 'T'),
(27, 'public static void main(String args[]) { Math m = new Math(); System.out.println(m.abs(2.6);', 'Compiler fails at line 1', 'Compiler fails at line 2', 'Compiler fails at the time of Math class instantiation', 'Compiler succeeds.', 'Compiler fails at the time of Math class instantiation', 'T'),
(28, 'Which of the following implement clear notion of one item follows another', 'List', 'Set', 'Map', 'Iterator', 'List', 'T'),
(29, 'Collection interface iterator method returns Iterator', 'true', 'false', 'yes', 'none of the above', 'true', 'T'),
(30, 'Which of the following places no constraints on the type of elements', 'Collection', 'collection', 'Map', 'Set', 'Map', 'T'),
(31, 'Which of the following gives Stack and Queue functionality.?', 'Map', 'Collection', 'List', ' Set', 'List', 'T'),
(32, 'Which of the following will compile without error?', ') File f = new File(\"/\",\"autoexec.bat\");', 'DataInputStream d = new DataInputStream(System.in);', 'OutputStreamWriter o = new OutputStreamWriter(System.out);', 'All Of The Above', 'All Of The Above', 'T'),
(33, 'Which of the following used to read and write to network sockets', 'InputStream', 'StreamReaders', 'OutputStream', 'Writers', 'InputStream', 'T'),
(34, 'Low Level Streams read input as bytes and writes as bytes', ' FileInputStream FIS = new FileInputStream(\"test.txt\")', 'File file = new File(\"test.txt\"); FileInputStream FIS = newFileInputStream(file)', ') File file = new File(\"c:\\\\\"); File file1 = new File(file,\"test.txt\");', 'All Of the above', 'All Of the above', 'T'),
(35, 'Choose all valid forms of the argument list for the FileOutputStream', 'FileOutputStream( FileDescriptor fd )', 'FileOutputStream( String n, boolean a )', 'FileOutputStream( boolean a )', 'FileOutputStream()', 'FileOutputStream( String n, boolean a )', 'T'),
(36, 'What is the class that has \"mode\" argument such as \"r\" or \"rw\" is required', ' DataInputStream', 'InputStream', 'RandomAccessFile', 'File', 'RandomAccessFile', 'T'),
(37, 'A header in CGI script can specify', 'format of the document', 'new location of the document', '(A) & (B) both', 'start of the document', 'format of the document', 'T'),
(38, 'All exceptions in Java are subclasses of built in class called', ' Exception', 'Error', 'Throwable.', 'Raise', 'Throwable.', 'T'),
(39, 'In 32 bit IP Addressing scheme all 1\'s represent', 'this computer', 'di rected broadcast', 'l imi ted broadcast', 'loop back', 'l imi ted broadcast', 'T'),
(40, 'DMSP stands for', 'Distributed Mail System Protocol', 'Distributed Message System Protocol', 'Distributed Message System Pool', 'Distributed Mail System Pool', 'Distributed Mail System Protocol', 'T'),
(41, 'Which Layer is not present in TCP/ IP model?', 'Appl icat ion Layer', 'Internet Layer', 'Transport Layer', 'Presentat ion Layer', 'Presentat ion Layer', 'T'),
(42, 'The Java interpreter is used for the execution of the source code.', 'True', 'False', 'none', 'none of these', 'True', 'T'),
(43, 'On successful compilation a file with the class extension is created.', 'True', 'False', 'none', 'none of these', 'True', 'T'),
(44, 'The Java source code can be created in a Notepad editor.', 'True', 'False', 'none', 'none of these', 'True', 'T'),
(45, 'The Java Program is enclosed in a class definition', 'True', 'False', 'none', 'none of these', 'True', 'T'),
(46, 'What declarations are required for every Java application?', 'main()', 'void', 'int', 'string', 'main()', 'T'),
(47, 'What are the two parts in executing a Java program and their purposes?', 'Java Compiler', 'Java Interpreter', 'both', 'none of these', 'both', 'T'),
(48, 'What are the three OOPs principles and define them?', 'Encapsulation', 'Inheritance', 'Polymorphism', 'All of the above', 'All of the above', 'T'),
(49, 'What is a compilation unit?', 'Java source code file.', 'byte code', 'both', 'none of these', 'Java source code file.', 'T'),
(50, 'What is the return type of program\'s main() function', 'void', 'void()', 'both', 'none of these', 'void', 'T');

-- --------------------------------------------------------

--
-- Table structure for table `php`
--

CREATE TABLE `php` (
  `id` int(11) NOT NULL DEFAULT 0 COMMENT 'TRIAL',
  `qs` longtext DEFAULT NULL COMMENT 'TRIAL',
  `op1` longtext DEFAULT NULL COMMENT 'TRIAL',
  `op2` longtext DEFAULT NULL COMMENT 'TRIAL',
  `op3` longtext DEFAULT NULL COMMENT 'TRIAL',
  `op4` longtext DEFAULT NULL COMMENT 'TRIAL',
  `ans` longtext DEFAULT NULL COMMENT 'TRIAL',
  `trial189` char(1) DEFAULT NULL COMMENT 'TRIAL'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='TRIAL';

--
-- Dumping data for table `php`
--

INSERT INTO `php` (`id`, `qs`, `op1`, `op2`, `op3`, `op4`, `ans`, `trial189`) VALUES
(1, '	What PHP stands for?', 'Hypertext Preprocessor', 'Pre Hypertext Processor', 'Pre Hyper Processor', 'Pre Hypertext Process', 'Hypertext Preprocessor', 'T'),
(2, '	Variables always start with a ........ in PHP', 'Pound-sign', 'Yen-sign', 'Dollar-sign', 'Euro-sign', 'Dollar-sign', 'T'),
(3, '	Which of the following method acts as a destructor function in a PHP class?', 'class_name()', '__destruct', 'destructor', 'None of the above', '__destruct', 'T'),
(4, '	PHP is ____________ scripting language', 'Server-side', 'Client-side', 'Middle-side', 'Out-side', 'Server-side', 'T'),
(5, '	In PHP Language variables are case sensitive', 'Depends on Website', 'Depends on Server', 'False', 'True', 'True', 'T'),
(6, '	In PHP each statement must be end with___________', '. (Dot)', '; (SemiColon)', '/(Slash)', ': (Colon)', '; (SemiColon)', 'T'),
(7, '	Which of the following operator is used to concatenate two strings?', '+(Plus)', '.(Dot)', '&(Ampersand)', '%(Percentage)', '.(Dot)', 'T'),
(8, '	Where setcookie function must appear in PHP?', 'Before tag', 'After tag', 'In tag', 'Anywhere', 'Before tag', 'T'),
(9, '	Data for a cookie stored ____________in  PHP?', 'In ISP Computer', 'In Server Computer', 'In User’s Computer', 'In Domain Computer', 'In User’s Computer', 'T'),
(10, '	What does fopen() function do in PHP?', 'It used to open Remote Server', 'It used to open Remote Computer', 'It used to open folders in PHP', 'It used to open files in PHP', 'It used to open files in PHP', 'T'),
(11, '	What does isset() function do in PHP?', 'There is no such function in PHP', 'It Checks whether variables is set or not', 'It Checks whether variables is free or not', 'It Checks whether variables is string or integer', 'It Checks whether variables is set or not', 'T'),
(12, '	Which of the following is used to check if session variabl already set or not in PHP?', 'session_start() function', '$_SESSION[]', 'session_destroy() function', 'isset() function', 'isset() function', 'T'),
(13, '	Which of the following method can be used to create a MySql database using PHP?', 'mysql_query()', 'mysql_connect()', 'mysql_close()', ' None of the above', 'mysql_query()', 'T'),
(14, '	All PHP classes come with a default constructor that takes .... arguments.', 'One', 'Two', 'Three', 'No', 'No', 'T'),
(15, '	Child classes are defined using the keyword .....', 'extents', 'child_class', 'extends', 'extend_class', 'extends', 'T'),
(16, '	Who is known as the father of PHP?', 'Willam Makepiece', 'Rasmus Lerdorf', 'Drek Kolkevi', 'List Barely', 'Rasmus Lerdorf', 'T'),
(17, '	How do you write \"Hello World\" in PHP', 'Document.write(“Hello World”)', 'Print.write(“Hello World”)', '“Hello World”', 'echo “Hello World”;', 'echo “Hello World”;', 'T'),
(18, '	What is the correct way to create a function in PHP?', 'function myFunction()', 'new_function myFunction()', 'create myFunction()', 'function(myFunction())', 'function myFunction()', 'T'),
(19, '	How many error levels are available in PHP?', '14', '15', '16', '17', '16', 'T'),
(20, '	Which of the following is not true?', 'PHP can be used to develop web applications.', 'PHP makes a website dynamic.', 'PHP applications can not be compiled.', 'PHP can not be embedded into html.', 'PHP can not be embedded into html.', 'T'),
(21, '	PHP scripts are enclosed within _______', '<?php> . . . </php>', '<?php . . . ?>', '?php . . . ?php', '<p> . . . </p>', '<?php . . . ?>', 'T'),
(22, '	mysql_connect( ) does not take following parameter', 'database host', 'database name', 'user ID', 'password', 'database name', 'T'),
(23, '	Which of the following is not a session function?', 'session_pw', 'session_decode', 'session_destroy', 'session_id', 'session_pw', 'T'),
(24, '	Which of following function return 1 when output is successful?', 'echo ( )', 'print ( )', 'both', 'None', 'print ( )', 'T'),
(25, 'PHP files have a default file extension of.', '.html', '.xml', '.ph', '.php', '.php', 'T'),
(26, '	We can use ___ to comment a single line?', '/?', '\\\\', '#', '/* */', '#', 'T'),
(27, '	Which of the below symbols is a newline character?', '\\r', '\\n', '/r', '/n', '\\n', 'T'),
(28, '	Which databases has PHP supported?', 'MySQL', 'Oracle', 'Database', 'SQL', 'MySQL', 'T'),
(29, '	The updated MySQL extension released with PHP 5 is typically referred to as..', 'MySQL', 'mysql', 'mysqly', 'mysqli', 'mysqli', 'T'),
(30, '	Which one of the following statements instantiates the mysqli class?', 'implements', 'inherit', 'extends', 'include', 'extends', 'T'),
(31, 'When you use the $_GET variable to collect data, the data is visible to..', 'only you', 'everyone', 'selected few', 'None', 'everyone', 'T'),
(32, '	When you use the $_POST variable to collect data, the data is visible to..', 'only you', 'everyone', 'selected few', 'None', 'only you', 'T'),
(33, '	PHP’s numerically indexed array begin with position __.', '1', '2', '0', '-1', '0', 'T'),
(34, '	Which of the functions is used to sort an array in descending order?', 'sort()', 'asort()', 'dsort()', 'rsort()', 'rsort()', 'T'),
(35, '	Which one of the following functions will convert a string to all uppercase?', 'strtoupper()', 'uppercase()', 'str_uppercase()', 'struppercase()', 'strtoupper()', 'T'),
(36, '	Which two predefined variables are used to retrieve information from forms?', '$GET & $SET', '$_GET & $_SET', '$__GET & $__SET', 'GET & SET', '$_GET & $_SET', 'T'),
(37, '	Which variable is used to collect form data sent with both the GET and POST methods?', '$BOTH', '$REQUEST', '$_BOTH', '$_REQUEST', '$_REQUEST', 'T'),
(38, '	What does SPL stand for?', 'Source PHP Library', 'Standard PHP List', 'Standard PHP Library', 'Source PHP List', 'Standard PHP Library', 'T'),
(39, '	Which is used to determine whether a class exists?', 'class_exist()', 'exist_class()', 'exist()', '__exist()', 'class_exist()', 'T'),
(40, '	The practice of creating objects based on predefined classes is often referred to as..', 'class creation', 'class instantiation', 'object creation', 'object instantiation', 'class instantiation', 'T'),
(41, '	Which one of the following is the right way to invoke a method?', 'object->methodName();', 'object::methodName();', '$object::methodName();', '$object->methodName();', '$object->methodName();', 'T'),
(42, '	Which one of the following statements is used to create a table?', 'CREATE table_name (column_type column_name);', 'CREATE table_name (column_name column_type);', 'CREATE TABLE table_name (column_name column_type);', 'CREATE TABLE table_name (column_type column_name);', 'CREATE TABLE table_name (column_name column_type);', 'T'),
(43, '	Sessions allow you to', 'store persistent user preference on a site', 'save user authentication information from page to page', 'create multipage forms', 'all of above', 'all of above', 'T'),
(44, '	The ............ function checks if the \"end-of-file\" (EOF) has been reached.', 'feof()', 'f_eof()', 'f_of()', 'feofs()', 'feof()', 'T'),
(45, '	The ........... function is used to read a single character from a file.', 'fgets()', 'fgetc()', 'fget()', 'fgetf()', 'fgetc()', 'T'),
(46, '	A valid class name starts with a .......,', 'Number', 'Period', 'Ampersand', 'Letter', 'Letter', 'T'),
(47, '	Once a class has been defined, objects can be created from the class with the ....... keyword.', 'new object', 'new', 'construct', 'both A and C', 'new', 'T'),
(48, '	You access an object’s properties and methods using the ....... Operator', '>>', '=>', '->', 'none of above', '->', 'T'),
(49, '	When you extend a class, the subclass inherits all of the ........ methods from the parent class.', 'Public', 'private', 'protected', 'both A and C', 'both A and C', 'T'),
(50, 'How would you add 1 to the variable $count?', 'incr count;', '$count++;', '$count =+1', 'incr $count;', '$count++;', 'T');

-- --------------------------------------------------------

--
-- Table structure for table `tbl1`
--

CREATE TABLE `tbl1` (
  `id` int(11) NOT NULL COMMENT 'TRIAL',
  `qs` longtext DEFAULT NULL COMMENT 'TRIAL',
  `op1` longtext DEFAULT NULL COMMENT 'TRIAL',
  `op2` longtext DEFAULT NULL COMMENT 'TRIAL',
  `op3` longtext DEFAULT NULL COMMENT 'TRIAL',
  `op4` longtext DEFAULT NULL COMMENT 'TRIAL',
  `ans` longtext DEFAULT NULL COMMENT 'TRIAL',
  `trial743` char(1) DEFAULT NULL COMMENT 'TRIAL'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='TRIAL';

--
-- Dumping data for table `tbl1`
--

INSERT INTO `tbl1` (`id`, `qs`, `op1`, `op2`, `op3`, `op4`, `ans`, `trial743`) VALUES
(1, 'Which of the following access specifier in C# allows a class to expose its member variables and member functions to other functions and objects?', 'Public', 'Private', 'Protected', 'Internal', 'Public', 'T'),
(2, 'Which of the following operator returns the address of an variable in C#?', 'sizeof', 'typeof', '&', '@', '&', 'T'),
(3, 'CLR is the .NET equivalent of _________.', 'Java Virtual Machine', 'Common Language Runtime', 'Common Type System', 'Common Language Specification', 'Common Language Runtime', 'T'),
(4, 'In C#, a subroutine is called a ________.', 'Function', 'Metadata', 'Method', 'Managed Code', 'Method', 'T'),
(5, 'All C# applications begin execution by calling the _____ method.', 'Class()', 'Main()', 'SubMain()', 'Namespace', 'Main()', 'T'),
(6, 'A _______ is an identifier that denotes a storage location.', 'Constant', 'Reference type', 'Variable', 'Object', 'Variable', 'T'),
(7, '_________ are reserved, and cannot be used as identifiers.', 'Keywords', 'literal', 'variables', 'Identifiers', 'Keywords', 'T'),
(8, 'Boxing converts a value type on the stack to an ______ on the heap.', 'Bool type', 'Instance type', 'Class type', 'Object type', 'Object type', 'T'),
(9, 'The character pair ?: is a________________available in C#.', 'Unary operator', 'Ternary operator', 'Decision operator', 'Functional operator', 'Ternary operator', 'T'),
(10, 'An _______ is a symbol that tells the computer to perform certain mathematical or logical manipulations.', 'Operator', 'Expression', 'Condition', 'Logic', 'Operator', 'T'),
(11, 'Arrays in C# are ______ objects.', 'Reference', 'Logical', 'Value', 'Arithmetic', 'Reference', 'T'),
(12, '_______ variables are visible only in the block they are declared.', 'System', 'Global', 'Local', 'Console', 'Local', 'T'),
(13, 'A structure in C# provides a unique way of packing together data of ______ types.', 'Different', 'Same', 'Invoking', 'Calling', 'Different', 'T'),
(14, 'Struct’s data members are ____________ by default.', 'Protected', 'Public', 'Private', 'Default', 'Private', 'T'),
(15, 'The methods that have the same name, but different parameter lists and different definitions is called______.', 'Method Overloading', 'Method Overriding', 'Method Overwriting', 'Method Overreading', 'Method Overloading', 'T'),
(16, 'The theory of _____ implies that user can control the access to a class, method, or variable.', 'Data hiding', 'Encapsulation', 'Information Hiding', 'Polymorphism', 'Encapsulation', 'T'),
(17, 'Inheritance is ______ in nature.', 'Commutative', 'Associative', 'Transitive', 'Iterative', 'Transitive', 'T'),
(18, 'In C#, having unreachable code is always an _____.', 'Method', 'Function', 'Iterative', 'Error', 'Error', 'T'),
(19, 'Which of the following statements is incorrect about delegate?', 'Delegates are reference types.', 'Only one method can be called using a delegate.', 'Delegates are object oriented.', 'Delegates are type-safe.', 'Only one method can be called using a delegate.', 'T'),
(20, ' Which of the following is NOT an Arithmetic operator in C#.NET?', '+', '/', '&', '-', '&', 'T'),
(21, 'Which of the following is NOT a Bitwise operator in C#.NET?', '&', '|', '^', '<<', '<<', 'T'),
(22, 'Which of the following is NOT a namespace in the .NET Framework Class Library?', 'System.Security', 'System.Process', 'System.Threading', 'System.Drawing', 'System.Process', 'T'),
(23, 'Which of the following is NOT a .NET Exception class?', 'StackMemoryException', 'Exception', 'InvalidOperationException', 'OutOfMemoryException', 'StackMemoryException', 'T'),
(24, 'Which of the following is the Object Oriented way of handling run-time errors?', 'OnError', 'Heresult', 'Error codes', 'Exceptions', 'Exceptions', 'T'),
(25, 'Which of the following keyword is used to overload user-defined types by defining static member functions?', 'op', 'opoverload', 'operator', 'operatoroverload', 'operator', 'T'),
(26, 'Which of the following statements about a String is correct?', 'A String is created on the stack.', 'Whether a String is created on the stack or the heap depends on the length of the String.', 'A String is created on the heap.', 'A String is a primitive.', 'A String is created on the heap.', 'T'),
(27, 'In C#.NET if we do not catch the exception thrown at runtime then which of the following will catch it?', 'Compiler', 'CLR', 'Linker', 'Loader', 'CLR', 'T'),
(28, 'Which of the following should be used to implement a \'Has a\' relationship between two entities?', 'Polymorphism', 'Encapsulation', 'Inheritance', 'Containership', 'Containership', 'T'),
(29, 'The reason that C# does not support multiple inheritances is because of ______.', 'Name collision', 'Method collision', 'Function collision', 'Interface collision', 'Name collision', 'T'),
(30, 'What is the wild card character in the SQL \"like\" statement?', '* (Asterisk)', '% (Percent)', '# (Pound)', '$ (Dollar)', '% (Percent)', 'T'),
(31, 'Features of Read only variables', 'Declaration and initialization is separated', 'It is allocated at compile time', 'It is allocated at runtime', 'all of the above', 'all of the above', 'T'),
(32, 'Which of the following .NET components can be used to remove unused references from the managed heap?', 'Class Loader', 'Garbage Collector', 'CTS', 'CLR', 'Garbage Collector', 'T'),
(33, 'A Constructor', 'is a method of a class ', 'is used to create objects ', 'Represents the behavior of an object ', 'maybe overloaded ', 'is a method of a class ', 'T'),
(34, 'Find any errors in the following BankAccount constructor: Public int BankAccount() { balance = 0; }', 'Name ', 'Formal parameters ', 'Return type ', 'No errors ', 'Return type ', 'T'),
(35, 'Every class directly or indirectly extends the______class.', 'System ', 'Object ', 'Drawing ', 'Console ', 'Object ', 'T'),
(36, 'An abstract class', 'may contain instance variables ', 'may extend another class ', 'Can\'t be Overloaded', 'all of the above ', 'may contain instance variables ', 'T'),
(37, 'Which of the following statements is correct for Constructor?', 'If we provide a one-argument constructor then the compiler still provides a zero-argument constructor.', 'Static constructors can use optional arguments.', 'Overloaded constructors cannot use optional arguments.', 'If we do not provide a constructor, then the compiler provides a zero-argument constructor.', 'If we do not provide a constructor, then the compiler provides a zero-argument constructor.', 'T'),
(38, 'Which of the following statements are correct about static functions?', 'Static functions are outside the class scope.', 'Static functions are invoked using class', 'Static functions can access static data as well as instance data.', 'Static functions are invoked using objects of a class.', 'Static functions are invoked using class', 'T'),
(39, 'Which of the following statements is correct about Managed Code?', 'Managed code is the code that is compiled by the JIT compilers.', 'Managed code is the code where resources are Garbage Collected.', 'Managed code is the code that is written to target the services of the CLR.', 'Managed code is the code that runs on top of Windows.', 'Managed code is the code that is written to target the services of the CLR.', 'T'),
(40, 'Code that targets the Common Language Runtime is known as', 'Unmanaged', 'Managed Code', 'Native Code', 'Legacy', 'Managed Code', 'T'),
(41, 'How many values is a function capable of returning?', '1', '0', 'Any number of values.', 'Depends upon how many params arguments does it use.', '1', 'T'),
(42, 'Which of the following CANNOT occur multiple number of times in a program?', 'namespace', 'Entrypoint', 'Class', 'Function', 'Entrypoint', 'T'),
(43, 'Which of the following statements is correct about Interfaces used in C#.NET?', 'All interfaces are derived from an Object class.', 'All interfaces are derived from an Object interface.', 'Interfaces can be inherited.', 'Interfaces can contain only method declaration.', 'Interfaces can be inherited.', 'T'),
(44, 'The CLR is physically represented by an assembly named _______.', 'mscoree.dll', 'mcoree.dll', 'msoree.dll', 'mscor.dll', 'mscoree.dll', 'T'),
(45, 'C# treats the multiple catch statements like cases in a _____________ statement.', 'If', 'Switch', 'For', 'While', 'Switch', 'T'),
(46, 'The___________keyword is new to C# 4.0, and is used to tell the compiler that a variable\'s type can change or that it is not known until runtime.', 'Covariance', 'Contravariance', 'Object', 'dynamic', 'dynamic', 'T'),
(47, '_______ methods are not supported for dynamic types.', 'Anonymous', 'Static', 'Extension', 'Abstract', 'Extension', 'T'),
(48, 'Which of the following is/are not types of arrays in C#?', 'Single-Dimensional', 'Jazzed arrays', 'Jagged arrays', 'Multidimensional', 'Jazzed arrays', 'T'),
(49, 'Managed methods will be marked as ------------ in MSIL code', 'mscorjit', 'cil', 'dgclr', 'None', 'cil', 'T'),
(50, 'Private Button print = new button();', 'creates a button control ', 'initializes a button control ', 'Calling Button Control', 'Both b and c', 'creates a button control ', 'T');

-- --------------------------------------------------------

--
-- Table structure for table `topic`
--

CREATE TABLE `topic` (
  `name` varchar(500) NOT NULL,
  `tbnm` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `topic`
--

INSERT INTO `topic` (`name`, `tbnm`) VALUES
('asp.net', 'asp'),
('C#', 'tbl1'),
('C++', 'cplus'),
('HTML', '#'),
('Java', 'java'),
('php', 'php'),
('www', '#');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `ad`
--
ALTER TABLE `ad`
  ADD PRIMARY KEY (`us`);

--
-- Indexes for table `asp`
--
ALTER TABLE `asp`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cplus`
--
ALTER TABLE `cplus`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `java`
--
ALTER TABLE `java`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `php`
--
ALTER TABLE `php`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl1`
--
ALTER TABLE `tbl1`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `topic`
--
ALTER TABLE `topic`
  ADD PRIMARY KEY (`name`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl1`
--
ALTER TABLE `tbl1`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'TRIAL', AUTO_INCREMENT=51;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
